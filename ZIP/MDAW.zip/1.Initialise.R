#
# Initialise script by Sofie Thijs
# sofie.thijs@uhasselt.be
# 14/03/2021
#

# Info: with the instructions below you will install all R packages needed for the MDAW workshop
# You only need to run this Initialise.R once.
# Text in green is information.
# Text in black are the commands, select them, and press (=>Run), icon here on the top.


### Step 1: Toggle off warnings, cleanup, check if you are in R4.0.4 (Tools > Global Options > R version)
options(warn=-1)
rm(list=ls())

### Step 2: Install Rtools40
# For windows users only (I assume you have windows 64-bit): Copy this link to your browser: https://cran.r-project.org/bin/windows/Rtools/rtools40-x86_64.exe
# Execute the .exe file.
# Important, in the popup it asks location to save, keep it to C:/Rtools
# If it asks 'add Rtools to path': cross this tick box to yes. Keep all other defaults, click next.
# When completed, close Rstudio and then open initialise.R again to make sure RTools takes effect.

### Step 3: Install now the required libraries. Select the lines, and click (=>Run)
.libPaths(c("./Rpackages", .libPaths()))
install.packages("rmarkdown")
install.packages("usethis")
install.packages("rmdformats")

### Step 4: Install renv
if (!requireNamespace("remotes"))
  install.packages("remotes")
remotes::install_github("rstudio/renv", force=TRUE)


### Step 5: Load the libraries. Select and click run.
library(rmarkdown)
library(renv)
library(rmdformats)


### Step 6: Now install and build the packages from my lock file.
#Select all lines from 61 to 69 and click (=>run). Type y, from yes in the Console and hit enter, when it asks, do you want to proceed.
#Write a second time y, from yes, and hit enter.
renv::restore(
project = NULL,
library = NULL,
lockfile = NULL, # null means use the one in the project directory.
packages = NULL,
repos = NULL,
clean = FALSE,
prompt = interactive()
)

## Take a break, as this step runs for about 30 min to complete. It is auto-installing all the packages.
## You can read here what renv does: https://rstudio.github.io/renv/articles/collaborating.html

# If this was successful, you can proceed to 2.setup.R and follow what is written there.


##############
## Finished ##
##############


### Print sessioninfo
sessionInfo()

