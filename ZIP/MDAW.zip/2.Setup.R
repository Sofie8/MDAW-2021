#
# Setup script by Sofie Thijs
# sofie.thijs@uhasselt.be
# 30/12/2020
#

# Info: this script will make input, config, results folders and copies the configuration template file to your config folder.

rm(list=ls()) # remove all objects from your workspace, start clean
library(tools)
library(rstudioapi)


########################################################################################################
# YOUR INPUT NEEDED: Give the path to the folder where you want to store the results. Change the green path between "".
# Tip: to find the path to a folder or directory, right click in this directory, properties, copy the path after 'Location:'. But the slashes need to point to the right in R.

main.folder <- file_path_as_absolute("G:/My Drive/1.Sofie/2.Onderzoek/2.Phd_neven/students_2020-2021/Monica/3.Results/2.RealSamples/4.Taxonomy/Downstream")
########################################################################################################


# Select everything (also the line 12) and press run
setwd(dirname(getActiveDocumentContext()$path))
getwd()
source("./Scripts/source_setup.R")



# If this was successful, you can proceed to 3.Run.R and follow what is written there.


##############
## Finished ##
##############


### Print sessioninfo
sessionInfo()
